# unique-meal

we need to run 

pip install bcrypt
pip install pycryptodome


then :

python um_members.py

start with using the super_Admin : 

super user with username=super_admin, password = Admin_123?
